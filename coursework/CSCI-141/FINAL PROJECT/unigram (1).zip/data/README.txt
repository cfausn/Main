Data format for .csv unigram files.   Each line has entries that are comma separated.

- The first entry in each row is the word.
- The second entry is the year.
- The third entry is the the number of times that the word appeared in any
book that year.
