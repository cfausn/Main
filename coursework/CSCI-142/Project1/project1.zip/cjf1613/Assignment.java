/**
 * Assignment.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */
package perp.tree.stu;

import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ActionNode;
import perp.tree.ExpressionNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Assignment assigns a value to the variable
 * @author Colin Fausnaught, (cjf1613)
 */
public class Assignment extends Object implements ActionNode {

    //private fields
    private String identifier;
    private ExpressionNode rhs;

    /**
     * Assignment() sets up an Assignment node
     * @param ident     String identifier to be given a value
     * @param rhs       ExpressionNode, a ExpressionNode of objects to be evaluated
     */
    public Assignment(String ident, ExpressionNode rhs){
        this.identifier = ident;
        this.rhs = rhs;
    }

    /**
     * execute will put the evaluated value and identifier into the SymbolTable
     * @param symTab the table where variable values are stored
     */
    public void execute(SymbolTable symTab){
        symTab.put(this.identifier, this.rhs.evaluate(symTab));
    }

    /**
     * infixDisplay prints the values to console
     */
    public void infixDisplay(){
        System.out.print(this.identifier + " ");
        System.out.print(":= ");
        this.rhs.infixDisplay();
        System.out.println();
    }

    /**
     * emit will return a list with Machine Instructions for the
     * Machine and InstructionReader Classes.
     * @return  emited values from the rhs in an ArrayList
     */
    public List<Machine.Instruction> emit(){
        //emit an instuction to push the value onto the stack
        List<Machine.Instruction> ret = new ArrayList<Machine.Instruction>();

        for(int i = 0; i < this.rhs.emit().size(); i++){
            ret.add(this.rhs.emit().get(i));
        }
        ret.add(new Machine.Store(this.identifier));
        return ret;
    }
}
