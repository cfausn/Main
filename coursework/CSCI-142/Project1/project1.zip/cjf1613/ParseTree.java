/**
 * ParseTree.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */

package perp.tree.stu;

import perp.Errors;
import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ActionNode;
import perp.tree.ExpressionNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Operations that are done on a Perp code parse tree.
 * @author Colin Fausnaught (cjf1613)
 */
public class ParseTree extends Object{

    //private fields, the SymbolTable and the program list
    private List<ActionNode> program = new ArrayList<ActionNode>();
    private SymbolTable symTab = new SymbolTable();
    /**
     * Parse the entire list of program tokens. The program is a
     * sequence of actions (statements), each of which modifies something
     * in the program's set of variables. The resulting parse tree is
     * stored internally.
     * @param program the token list (Strings)
     */
    public ParseTree( List< String > program ) {
        int counter = 0;
        int size = program.size();

        for(int i = 0; i < size; i++){
            if(!(program.contains(":=") || program.contains("@"))){
                //Error Checking, if there is no := or @ call this
                Errors.error("Does not contain := or @", null);
            }
            //The following is used to for assigning a value to a variable
            else if(program.get(i).equals(":=") && size > (i+2)){
                    if(size == 3 || program.get(i+3).equals(":=")){
                        if(!(program.get(i+2).matches("[0-9]+") ||
                                program.get(i+2).matches("[a-zA-Z]+"))){
                            //Error Checking for illegal token
                            Errors.error("Illegal token! Token is: ", program.get(i+2));
                        }
                        //This will assign a new value to the given variable
                        ExpressionNode constNode = new Constant(Integer.parseInt(program.get(i + 2)));
                        Assignment newVar = new Assignment(program.get(i+1),constNode);
                        this.program.add(newVar);
                        i+=2;
                }
            }
            else{
                //Otherwise execute whatever operations are needed
                ArrayList<String> tempArray = new ArrayList<String>();
                tempArray.add(program.get(i));
                counter = i + 1;
                while(size > counter &&
                        !(program.get(counter).equals(":=")) &&
                        !(program.get(counter).equals("@"))){
                    tempArray.add(program.get(counter));
                    counter += 1;
                }
                if(program.get(0).equals("@")) {
                    tempArray.remove(0);
                    this.program.add(new Print(parseExpr(tempArray)));
                }

                else if(program.get(i-1).equals("@"))this.program.add(new Print(parseExpr(tempArray)));
                else this.program.add(parseAction(tempArray));
                i = counter;
            }
        }
        List<String> tempList = new ArrayList<String>();

    }

    /**
     * Parse the next action (statement) in the list.
     * (This method is not required, just suggested.)
     * @param program the list of tokens
     * @return a parse tree for the action
     */
    private ActionNode parseAction( List< String > program ) {
        int counter = 1;
        ArrayList<String> newProgram = new ArrayList<String>();

        while (counter < program.size()){
            newProgram.add(program.get(counter));
            counter+=1;
        }

        return new Assignment(program.get(0),parseExpr(newProgram));

    }

    /**
     * Parse the next expression in the list.
     * (This method is not required, just suggested.)
     * @param program the list of tokens
     * @return a parse tree for this expression
     */
    private ExpressionNode parseExpr( List< String > program ) {

        if(program == null) return null;
        else if(program.size() == 0) return null;
        else{
            if(binaryExp(program.get(0))){
                String ident = program.get(0);
                program.remove(0);
                return new BinaryOperation(ident, parseExpr(program), parseExpr(program));
            }
            else if(unaryExp(program.get(0))){
                String ident = program.get(0);
                program.remove(0);
                return new UnaryOperation(ident,parseExpr(program));
            }
            else if(program.get(0).matches("[a-zA-Z]+")){
                String ident = program.get(0);
                program.remove(0);
                return new Variable(ident);
            }
            else if(program.get(0).matches("[0-9]+")){
                String ident = program.get(0);
                program.remove(0);
                return new Constant(Integer.parseInt(ident));
            }
            else {
                //Error checking for invalid token
                Errors.error("Invalid token", program.get(0));
                return null;
            }
        }
    }


    /**
     * binaryExp checks if a string is part of a Binary Operation
     * @param s string to be checked
     * @return  True or False depending if it's a binary operator
     */
    public boolean binaryExp(String s){
        return s.equals("+") ||
                s.equals("*") ||
                s.equals("-") ||
                s.equals("//");
    }
    /**
     * unaryExp checks if a string is part of a Unary Operation
     * @param s string to be checked
     * @return  True or False depending if it's a unary operator
     */
    public boolean unaryExp(String s){
        return s.equals("_") ||
                s.equals("#");
    }

    /**
     * Print the program the tree represents in a more typical
     * infix style, and with one statement per line.
     * @see perp.tree.ActionNode#infixDisplay()
     */
    public void displayProgram() {
        for(int i = 0; i < this.program.size(); i++){
            this.program.get(i).infixDisplay();
        }
    }

    /**
     * Run the program represented by the tree directly
     * @see perp.tree.ActionNode#execute(perp.SymbolTable)
     */
    public void interpret() {
        for(int i = 0; i < this.program.size(); i++){
            this.program.get(i).execute(symTab);
        }

        this.symTab.dump();
    }

    /**
     * Build the list of machine instructions for
     * the program represented by the tree.
     * @return the Machine.Instruction list
     * @see perp.machine.stu.Machine.Instruction#execute()
     */
    public List< Machine.Instruction > compile() {
        List<Machine.Instruction> returnedInst = new ArrayList<Machine.Instruction>();

        for(ActionNode node : this.program){
            if(node.emit().size() == 1){
                returnedInst.add(node.emit().get(0));
            }
            else{
                for(int i = 0; i < node.emit().size(); i++){
                    returnedInst.add(node.emit().get(i));
                }
            }
        }
        return returnedInst;
    }

}
