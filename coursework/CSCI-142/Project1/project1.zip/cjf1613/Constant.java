/**
 * Constant.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */

package perp.tree.stu;

import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ExpressionNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Constant is the ExpressionNode representation of a constant
 * @author Colin Fausnaught, (cjf1613)
 */
public class Constant extends Object implements ExpressionNode{

    //the value of the constant
    private int value;

    /**
     * Store the integer value in this new Constant
     * @param value the integer of the constant will hold
     */
    public Constant(int value){
        this.value = value;
    }

    /**
     * infixDisplay prints this Constant's value on standard output
     */
    public void infixDisplay(){

        System.out.print(" " + this.value + " ");
    }

    /**
     * evaluate Evaluates the constant
     * @param symTab symbol table, if needed, to fetch variable values
     * @return The constant's value
     */
    public int evaluate(SymbolTable symTab){
        return this.value;
    }

    /**
     * emit's an instruction to push the value onto the stack
     * @return a list containing one instruction
     */
    public List<Machine.Instruction> emit(){
        //Emit an instruction to push the value onto the stack
        List<Machine.Instruction> ret = new ArrayList<Machine.Instruction>();
        ret.add(new Machine.PushConst(this.value));
        return ret;
    }

}
