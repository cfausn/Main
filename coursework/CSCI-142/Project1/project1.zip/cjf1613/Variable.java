/**
 * Variable.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */

package perp.tree.stu;
import perp.Errors;
import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ExpressionNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Variable is the ExpressionNode representation of a variable
 * @author Colin Fausnaught, (cjf1613)
 */
public class Variable extends Object implements ExpressionNode{

    //Variable name
    private String name;

    /**
     * Set the name of the new Variable
     * @param name  The name of the new variable
     * */

    public Variable(String name){
        this.name = name;
    }

    /**
     * infixDisplay prints the Variables name in standard output
     */
    public void infixDisplay(){
        System.out.print(" " + this.name + " ");
    }

    /**
     * evaluate Evaluates a variable by fetching its value
     *
     * @param symTab symbol table, if needed, to fetch variable values
     * @return  this variable's current value in the symbol table
     */
    public int evaluate(SymbolTable symTab){
        if(symTab.exists(this.name)) return symTab.get(this.name);
        else {
            Errors.error("Variable never given a value! Variable is: ", this.name);
            return 0;
        }
    }

    /**
     * Emit a LOAD instruction that pushes the Variable's value onto the stack
     * @return a list containing a single LOAD instruction
     */
    @Override
    public List<Machine.Instruction> emit(){
        //return a list containing a single LOAD instruction
        List<Machine.Instruction> ret = new ArrayList<Machine.Instruction>();
        ret.add(new Machine.Load(this.name));
        return ret;
    }
}
