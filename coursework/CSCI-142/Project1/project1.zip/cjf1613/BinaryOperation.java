/**
 * BinaryOperation.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */

package perp.tree.stu;

import perp.Errors;
import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ExpressionNode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * BinaryOperation will store and execute binary operations
 * @author Colin Fausnaught, (cjf1613)
 */
public class BinaryOperation extends Object implements ExpressionNode {
    //Constant fields
    public static final String ADD = "+";
    public static final String DIV = "//";
    public static final String MUL = "*";
    public static final String SUB = "-";
    public static final Collection<String> OPERATORS = new ArrayList<String>();

    //Private fields
    private String operator;
    private ExpressionNode leftChild;
    private ExpressionNode rightChild;

    /**
     * BinaryOperation creates a new BinaryOperation node
     * @param operator      the string representation of the operation
     * @param leftChild     the left operand
     * @param rightChild    the right operand
     */
    public BinaryOperation(String operator, ExpressionNode leftChild,
                           ExpressionNode rightChild){
        OPERATORS.add(ADD);
        OPERATORS.add(DIV);
        OPERATORS.add(MUL);
        OPERATORS.add(SUB);

        this.operator = operator;
        this.leftChild = leftChild;
        this.rightChild = rightChild;
    }

    /**
     * evaluate computes the result from evaluating both operands and applying
     * the operand to them.
     * @param symTab symbol table, if needed, to fetch variable values
     * @return  the result of the computation
     */
    public int evaluate(SymbolTable symTab){
        if(OPERATORS.contains(this.operator)){
            if(this.operator.equals(ADD)) return this.leftChild.evaluate(symTab) + this.rightChild.evaluate(symTab);
            else if(this.operator.equals(DIV)) {
                if(!(rightChild.evaluate(symTab) == 0)){
                    return (int)this.leftChild.evaluate(symTab) / this.rightChild.evaluate(symTab);
                }
                else {
                    Errors.error("Cannot divide by 0!", null);
                    return 0;
                }
            }
            else if(this.operator.equals(MUL)) return this.leftChild.evaluate(symTab) * this.rightChild.evaluate(symTab);
            else return this.leftChild.evaluate(symTab) - this.rightChild.evaluate(symTab);
        }
        else{
            Errors.error("Illegal Binary Operator! Operator is: ", this.operator);
            return 0;
        }
    }

    /**
     * Print, on standard output, the infixDisplay of the two child nodes
     * separated by the operator and surrounded by parentheses.
     */
    public void infixDisplay(){
        System.out.print("(");
        this.leftChild.infixDisplay();
        System.out.print(this.operator);
        this.rightChild.infixDisplay();
        System.out.print(")");
    }

    /**
     * Emit the Machine instructions necessary to perform the computation of
     * this BinaryOperationEmit the Machineinstructions necessary to perform the
     * computation of this BinaryOperation
     * @return a list containing instructions for the left operand, instructions for
     *          the right operand, and the instruction to perform the operation
     */

    @Override
    public List<Machine.Instruction> emit(){
        //emit an instruction to push the value onto the stack
        List<Machine.Instruction> ret = new ArrayList<Machine.Instruction>();

        if(this.operator.equals(ADD)){
            for(int i = 0; i < this.leftChild.emit().size(); i++){
                ret.add(this.leftChild.emit().get(i));
            }
            for(int i = 0; i < this.rightChild.emit().size(); i++){
                ret.add(this.rightChild.emit().get(i));
            }
            ret.add(new Machine.Add());
        }
        else if(this.operator.equals(SUB)){
            for(int i = 0; i < this.leftChild.emit().size(); i++){
                ret.add(this.leftChild.emit().get(i));
            }
            for(int i = 0; i < this.rightChild.emit().size(); i++){
                ret.add(this.rightChild.emit().get(i));
            }
            ret.add(new Machine.Subtract());
        }
        else if(this.operator.equals(MUL)){
            for(int i = 0; i < this.leftChild.emit().size(); i++){
                ret.add(this.leftChild.emit().get(i));
            }
            for(int i = 0; i < this.rightChild.emit().size(); i++){
                ret.add(this.rightChild.emit().get(i));
            }
            ret.add(new Machine.Multiply());
        }
        else if(this.operator.equals(DIV)){
            for(int i = 0; i < this.leftChild.emit().size(); i++){
                ret.add(this.leftChild.emit().get(i));
            }
            for(int i = 0; i < this.rightChild.emit().size(); i++){
                ret.add(this.rightChild.emit().get(i));
            }
            ret.add(new Machine.Divide());
        }

        return ret;
    }

}
