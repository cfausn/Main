/**
 * ActionSequence.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */

package perp.tree.stu;

import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ActionNode;
import java.util.ArrayList;
import java.util.List;

/**
 * ActionSequence will hold the actions to be performed by the program.
 *
 * @author Colin Fausnaught (cjf1613)
 */
public class ActionSequence extends Object implements ActionNode {

    /** nodeArrayList is an ArrayList of action nodes **/
    private ArrayList<ActionNode> nodeArrayList = new ArrayList<ActionNode>();

    //Default constructor
    public ActionSequence(){
    }

    /**
     * addAction adds a new action node to the arrayList
     * @param newNode   ActionNode to be added
     */
    public void addAction(ActionNode newNode){
        //add a child of this ActionSequence node
        this.nodeArrayList.add(newNode);
    }

    /**
     * execute will execute each ActionNode in the arrayList
     * @param symTab the table where variable values are stored
     */
    public void execute(SymbolTable symTab){
        //execute each ActionNode in this object, from first-added
        //to last-added
        for(int i = 0; i < this.nodeArrayList.size(); i++){
            this.nodeArrayList.get(i).execute(symTab);
        }
    }

    /**
     * infixDisplay will print each ActionNode from their own
     * infixDisplay methods.
     */

    public void infixDisplay(){
        //show the infix displays of all children on standard output
        //The order is first-added to last-added
        for(int i = 0; i < this.nodeArrayList.size(); i++){
            this.nodeArrayList.get(i).infixDisplay();
        }
    }

    /**
     * emit will return a list with Machine Instructions for the
     * Machine and InstructionReader Classes.
     * @return  emited values from each ActionNode in an ArrayList
     */
    @Override
    public List<Machine.Instruction> emit(){
        //emit an instruction to push the value onto the stack
        List<List<Machine.Instruction>> macList = new ArrayList<>();
        for(ActionNode node : this.nodeArrayList){
            macList.add(node.emit());
        }
        return null;
    }

}
