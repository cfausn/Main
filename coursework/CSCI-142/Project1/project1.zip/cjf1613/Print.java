/**
 * Print.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */

package perp.tree.stu;

import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ActionNode;
import perp.tree.ExpressionNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Print is the ActionNode that print's a value
 * @author Colin Fausnaught, (cjf1613)
 */
public class Print extends Object implements ActionNode {
    //the ExpressionNode to print
    private ExpressionNode printee;

    /**
     * Set up a print node
     * @param printee the expression to be evaluated and printed
     */
    public Print(ExpressionNode printee){
        this.printee = printee;
    }

    /**
     * execute will evaluate the expression and print it to the console
     * @param symTab the table where variable values are stored
     */
    public void execute(SymbolTable symTab){
        System.out.println("===" + this.printee.evaluate(symTab));
    }

    /**
     * inifixDisplay Shows this statement on standard output
     */
    public void infixDisplay(){
        System.out.print("Print ");
        printee.infixDisplay();
        System.out.println();
    }

    /**
     * This method returns the code emitted by the printee node that pushes the value
     * of the printee expression onto the stack, followed by a PRINT instruction
     * @return a list of instructions ending in the ones that compute
     *         the value to be printed, and print it.
     */
    @Override
    public List<Machine.Instruction> emit(){
        //emit an instuction to push the value onto the stack
        List<Machine.Instruction> ret = new ArrayList<Machine.Instruction>();
        for(int i = 0; i < this.printee.emit().size(); i++){
            ret.add(this.printee.emit().get(i));
        }
        ret.add(new Machine.Print());
        return ret;
    }
}
