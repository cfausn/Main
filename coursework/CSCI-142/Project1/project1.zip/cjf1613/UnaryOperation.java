/**
 * UnaryOperation.java
 *
 * Version:
 * 1
 *
 * Revisions:
 * 2/28/15, Final Revision
 */

package perp.tree.stu;

import perp.Errors;
import perp.SymbolTable;
import perp.machine.stu.Machine;
import perp.tree.ExpressionNode;

import java.util.ArrayList;
import java.util.List;

/**
 * UnaryOperation will store and execute unary operations
 * @author Colin Fausnaught, (cjf1613)
 */
public class UnaryOperation extends Object implements ExpressionNode {
    //Constant fields
    public static final String NEG = "_";
    public static final String SQRT = "#";
    public static final List<String> OPERATORS = new ArrayList<String>();

    //private fields to hold the operator and the expressionNode
    private String operator;
    private ExpressionNode expressionNode;

    /**
     * UnaryOperation creates a new UnaryOperation node
     *
     * @param operator      The string representation of the operation
     * @param expr          the operand
     */
    public UnaryOperation(String operator, ExpressionNode expr){
        OPERATORS.add(NEG);
        OPERATORS.add(SQRT);

        this.operator = operator;
        this.expressionNode = expr;
    }

    /**
     * Compute the result of evaluating the expression and applying the operator to it
     * @param symTab symbol table, if needed, to fetch variable values
     * @return  the result of the computation
     */
    public int evaluate(SymbolTable symTab){
        //compute the result of evaluating the expression and applying the operator to it
        if(OPERATORS.contains(this.operator)) {
            if (this.operator.equals(NEG)) {
                return this.expressionNode.evaluate(symTab) * -1;
            } else return (int)Math.sqrt(this.expressionNode.evaluate(symTab));
        }
        else {
            Errors.error("Illegal Unary Operator! Operator is: ", this.operator);
            return 0;
        }
    }

    /**
     * infixDisplay prints on standard output the operator and the
     * expressionNode
     * */
    public void infixDisplay(){
        if(OPERATORS.contains(this.operator)){
            System.out.print(this.operator);
            this.expressionNode.infixDisplay();
        }

    }

    /**
     * Emit the Machine instructions necessary to perform the
     * computation of this UnaryOperation
     * @return a list containing instructions for the expression
     *          and the instruction to perform the operation
     */
    @Override
    public List<Machine.Instruction> emit(){
        //emit an instuction to push the value onto the stack
        List<Machine.Instruction> ret = new ArrayList<Machine.Instruction>();

        if(this.operator.equals(NEG)){
            for(int i = 0; i < this.expressionNode.emit().size(); i++){
                ret.add(this.expressionNode.emit().get(i));
            }
            ret.add(new Machine.Negate());
        }
        else if(this.operator.equals(SQRT)){
            for(int i = 0; i < this.expressionNode.emit().size(); i++){
                ret.add(this.expressionNode.emit().get(i));
            }
            ret.add(new Machine.SquareRoot());
        }
        return ret;
    }
}
