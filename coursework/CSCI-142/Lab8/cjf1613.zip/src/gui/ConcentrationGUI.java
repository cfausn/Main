/*
 * File: ConcentrationGUI.java
 *
 * This application uses java.util.Observer notifications.
 */

package gui;


import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.Card;
import model.ConcentrationModel;



/**
 * The ConcentrationGUI application is the GUI for Concentration.
 *
 * @author Colin Fausnaught
 */
public class ConcentrationGUI extends Application implements Observer {

    /**
     * model for the game
     */
    private ConcentrationModel model;

    /**
     * Image shown for a face-down card
     */
    private Image faceDown;
    private int moves;

    // OTHER DECLARATIONS GO HERE.
    private String theLabel = "Select the first card.";

    private ArrayList<CButton> buttons = new ArrayList<CButton>();
    private Stage mainStage;
    /**
     * Images shown for the face up cards.
     * Indices are the numbers the model associates with each card
     * and that determine what matches what.
     * This means that there are half as many images as there are
     * cards on the board.
     */
    private final ArrayList<Image> faceUps =
            new ArrayList<>( ConcentrationModel.NUM_PAIRS );

    /**
     * Load up the card images provided for the game.
     */
    private void installImages() {

        this.faceDown =
                new Image(getClass().getResourceAsStream("EmptyHead.jpg"));

        ArrayList<String> imagenames =
                new ArrayList<>(ConcentrationModel.NUM_PAIRS);
        imagenames.add("atd.jpg");
        imagenames.add("bks.jpg");
        imagenames.add("jeh.jpg");
        imagenames.add("axm.jpg");
        imagenames.add("rwd.jpg");
        imagenames.add("lm.jpg");
        imagenames.add("sps.jpg");
        imagenames.add("tjb.jpg");

        Class<?> myClass = this.getClass();
        for (int n = 0; n < ConcentrationModel.NUM_PAIRS; ++n) {
            try {
                String imageName = imagenames.get(n);
                InputStream imgStream = myClass.getResourceAsStream(imageName);
                Image image = new Image(imgStream);
                this.faceUps.add(image);
                imgStream.close();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Intializes non-graphic parameters. Sets observer
     */
    @Override
    public void init() {
        // TODO non-graphic setup code goes here.
        this.moves = 0;
        this.model = new ConcentrationModel();
        this.model.addObserver(this);

    }

    /**
     * start constructs the layout for the game.
     *
     * @param stage container (window) in which to render the UI
     */
    @Override
    public void start(Stage stage) {
        // TODO fill this method in, probably with the help of
        // subordinate private methods.
        Scene scene = new Scene(this.makeMainPane());
        stage.setTitle("Concentration");
        stage.setScene(scene);
        stage.show();
        this.mainStage = stage;

    }

    /**
     * Observer function (necessary to update the GUI)
     */
    @Override
    public void update(Observable o, Object arg) {
        // TODO Write your observer code here.
        if(this.model.getMoveCount() == 0){
            start(this.mainStage);
        }
        else {
            updateStage();
        }

    }

    // OTHER CODE GOES HERE

    /**
     * updates the stage based on an observable change. Updates
     * the main panel and shows objects based on ConcentrationModel.java
     */
    private void updateStage() {
        // subordinate private methods.

        Scene scene = new Scene(this.makeMainPaneUpdated());
        this.mainStage.setTitle("Concentration");
        this.mainStage.setScene(scene);
        this.mainStage.show();


    }

    /**
     * Makes a pane similar to the initial pane, however this function
     * toggles the cards based on the arraylist of cards from ConcentrationModel
     * @return a BorderPane with all the cards and buttons on it
     */
    private Parent makeMainPaneUpdated(){
        BorderPane bp = new BorderPane();
        bp.setPrefWidth(400);

        bp.setTop(new Label(theLabel));


        GridPane gp = new GridPane();

        ArrayList<Card> cards = this.model.getCards();

        gp.setPadding(new Insets(0, 4, 0, 4));

        int counter = 0;
        for (int i = 0; i < 4; i++) {

            for (int index = 0; index < 4; index++) {

                if(cards.get(counter).isFaceUp() && !(this.buttons.get(counter).isFlipped())){
                    this.buttons.get(counter).toggleImage();
                }
                else if(!(cards.get(counter).isFaceUp()) && this.buttons.get(counter).isFlipped()){
                    this.buttons.get(counter).toggleImage();

                }

                gp.add(this.buttons.get(counter), index, i);
                counter++;
            }
        }



        bp.setCenter(gp);


        ResetButton reset = new ResetButton("Reset", this.model);

        UndoButton undo = new UndoButton("Undo",this.model);

        Label move = new Label(this.model.getMoveCount() + " Moves" );

        HBox hb = new HBox();
        move.setPadding(new Insets(0,0,0,200));
        hb.getChildren().addAll(reset, undo, move);

        hb.setPadding(new Insets(0,0,0,160));


        bp.setBottom(hb);

        return bp;
    }


    /**
     * Makes the main Pane, only called when Reset is called
     * and when the program first loads
     * @return a fresh Pane with cards and buttons
     */
    private Parent makeMainPane(){
        this.buttons = new ArrayList<>();
        BorderPane bp = new BorderPane();
        bp.setPrefWidth(400);
        bp.setTop(new Label(theLabel));


        installImages();

        GridPane gp = new GridPane();

        ArrayList<Card> cards = this.model.getCards();


        gp.setPadding(new Insets(0, 4, 0, 4));

        int counter = 0;
        for(int i = 1; i < 5; i++ ) {

            for(int index = 1; index < 5; index++) {

                int num = cards.get(counter).getNumber();

                CButton b = new CButton(num,counter++,this.faceUps.get(num), this.faceDown, this.model);
                this.buttons.add(b);
                gp.add(b, index, i);


            }

        }


        bp.setCenter(gp);


        ResetButton reset = new ResetButton("Reset", this.model);

        UndoButton undo = new UndoButton("Undo",this.model);

        Label move = new Label(this.model.getMoveCount() + " Moves" );

        HBox hb = new HBox();
        move.setPadding(new Insets(0,0,0,200));
        hb.getChildren().addAll(reset, undo, move);

        hb.setPadding(new Insets(0,0,0,160));


        bp.setBottom(hb);

        return bp;
    }





    /**
     *
     * main entry point launches the JavaFX GUI.
     *
     * @param args not used
     */
    public static void main(String[] args) {
        Application.launch(args);
    }
}
