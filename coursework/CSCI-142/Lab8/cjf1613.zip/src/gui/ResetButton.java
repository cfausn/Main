package gui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import model.ConcentrationModel;

/**
 * Reset is the rest button, which extends Button
 * @author Colin Fausnaught (cjf1613)
 */
public class ResetButton extends Button {
    private String field;
    private ConcentrationModel model;

    /**
     * Constructor for ResetButton
     * @param field - the string value of the field ("reset")
     * @param model - the model, ConcentrationModel
     */
    public ResetButton(String field, ConcentrationModel model){
        this.field = field;
        this.setText(this.field);
        this.model = model;

        this.setOnAction(new ResetHandler(this));
    }

    /**
     * returns the model, ConcentrationModel
     * @return the current model
     */
    public ConcentrationModel getModel(){
        return this.model;
    }
}

class ResetHandler implements EventHandler<ActionEvent> {
    private ResetButton button;

    public ResetHandler(ResetButton button){
        this.button = button;
    }
    @Override
    public void handle(ActionEvent event) {

        button.getModel().reset();

    }
}
