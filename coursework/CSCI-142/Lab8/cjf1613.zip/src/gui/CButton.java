package gui;

import javafx.scene.control.Button;
import javafx.scene.image.Image;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import model.ConcentrationModel;



/**
 * CButton is a card button, which extends Button.
 * @author Colin Fausnaught (cjf1613)
 */
public class CButton extends Button  {
    private int ID;
    private int pos;
    private Image imgFace;
    private Image imageBack;
    private boolean flipped;
    private boolean matched;
    private ConcentrationModel model;


    /**
     * The Card Button, intializes and uses it.
     * @param ID - the ID of the card, int
     * @param pos - the position of the card on the BorderPane
     * @param face - the face image of the card
     * @param back - the back image of the card
     * @param model - ConcentrationModel model
     */
    public CButton(int ID,int pos, Image face, Image back, ConcentrationModel model) {
        this.ID = ID;
        this.imgFace = face;
        this.imageBack = back;
        this.flipped = false;
        this.matched = false;
        this.pos = pos;

        this.model = model;
        this.setGraphic(new javafx.scene.image.ImageView(imageBack));

        this.setOnAction(new MouseHandler(this));
    }

    /**
     * gets the ID of the card
     * @return the ID (integer)
     */
    public int getID() {
        return this.ID;

    }

    /**
     * gets the positon of the card
     * @return the Position (integer)
     */
    public int getPos() {
        return this.pos;

    }

    /**
     * gets the model (to be used in actionevents)
     * @return the model
     */
    public ConcentrationModel getModel(){
        return this.model;
    }

    /**
     * Gets the image card face
     * @return the Image of the face of the card
     */
    public Image getImgFace() {
        return this.imgFace;
    }

    /**
     * gets the image card back
     * @return the Image of the back of the card
     */
    public Image getImgBack() {
        return this.imageBack;
    }

    /**
     * Toggles the image using flipped and the two images
     */
    public void toggleImage(){
        if(flipped){
            this.setGraphic(new javafx.scene.image.ImageView(getImgBack()));
            this.flipped = false;

        }
        else{
            this.setGraphic(new javafx.scene.image.ImageView(getImgFace()));
            this.flipped = true;
        }
    }

    /**
     * returns the value of isFlipped
     * @return the boolean value of whether the card was flipped
     */
    public boolean isFlipped(){
        return this.flipped;
    }



}

class MouseHandler implements EventHandler<ActionEvent> {
    private CButton button;

    /**
     * This EventHandler executes when the button is
     * clicked.
     * @param button the Card button
     */
    public MouseHandler(CButton button){
        this.button = button;
    }
    @Override
    public void handle(ActionEvent event) {

        this.button.getModel().selectCard(this.button.getPos());
    }
}
