package gui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import model.ConcentrationModel;

/**
 * UndoButton is the undo button, which extends Button
 * @author Colin Fausnaught (cjf1613)
 */
public class UndoButton extends Button {
    private String field;
    private ConcentrationModel model;

    /**
     * Constructor for UndoButton
     * @param field - the string value of the field ("undo")
     * @param model - the model, ConcentrationModel
     */
    public UndoButton(String field, ConcentrationModel model) {
        this.field = field;
        this.setText(field);
        this.model = model;

        this.setOnAction(new UndoHandler(this));
    }

    /**
     * returns the model, ConcentrationModel
     * @return the current model
     */
    public ConcentrationModel getModel() {
        return this.model;
    }
}


class UndoHandler implements EventHandler<ActionEvent> {
    private UndoButton button;

    public UndoHandler(UndoButton button){
        this.button = button;
    }
    @Override
    public void handle(ActionEvent event) {

        button.getModel().undo();

    }
}

