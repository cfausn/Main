/**
 * The model package is the home of the Concentration image game.
 */

package model;

