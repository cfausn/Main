/**
 * GremlinsBridge.java
 */

import java.util.*;

/**
 * GremlinsBridge class
 * @author Colin Fausnaught (cjf1613)
 */
public class GremlinsBridge extends Object{
    private int max;
    private Queue<Mogwai> waiting;
    private ArrayList<Mogwai> bridge;


    /**
     * Create a GremlinsBridge with a given capacity.
     * The municipal authority creates a GremlinsBridge for each bridge
     * that needs management.
     * @param max - the maximum capacity of the GremlinsBridge.
     */
    public GremlinsBridge(int max){
        this.max = max;
        this.waiting = new LinkedList<Mogwai>();
        this.bridge = new ArrayList<Mogwai>();
    }

    /**
     * Request permission to go onto the gremlin's bridge. Mogwais
     * call this method to ask the gremlin to put them on the queue
     * of mogwais trying to get on the bridge. The Mogwai (thread)
     * waits until it becomes the head of the queue and there is room
     * on the gremlin's bridge.
     * @param thisMogwai - the Mogwai trying to get on the bridge (the same object as Thread calling this method).
     */
    public void enterBridgePlease(Mogwai thisMogwai){
        System.out.println("The gremlin scowls " + '"' + "Get in line!" + '"' + " when "
        + thisMogwai.getName() + " shows up at the bridge.");
        if(this.bridge.size() < this.max) {
            if (this.waiting.size() > 0) {
                Mogwai addMog = this.waiting.remove();
                this.bridge.add(addMog);
                this.waiting.add(thisMogwai);
                addMog.setSecsToOne();
                addMog.run();

            }
            else {
                this.bridge.add(thisMogwai);
                thisMogwai.setSecsToOne();
                thisMogwai.run();
            }

        }

        else{

            this.waiting.add(thisMogwai);
        }
    }

    /**
     * Tell the gremlin of a GremlinsBridge that a mogwai has
     * left the bridge so that the gremlin can let other mogwais
     * get on if there is room.
     * If the size of the waiting list isn't zero, then adds it
     * to the bridge.
     */
    public void leave(){

        for(int x = 0; x < this.bridge.size(); x++){
            if(this.bridge.get(x).getSecsOnBridge() == -1){
                this.bridge.remove(x);
            }
        }
        if(this.waiting.size() != 0) {
            Mogwai addMog = this.waiting.remove();
            this.bridge.add(addMog);
            addMog.setSecsToOne();
            addMog.run();
        }

    }


}
