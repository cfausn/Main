/**
 * GremlinsBridge.java
 */

/**
 * Mogwai Class
 * @author Colin Fausnaught (cjf1613)
 */
public class Mogwai extends Thread {
    private int crossTime;
    private String destination;
    private GremlinsBridge bridge;
    private int secsOnBridge;

    /**
     * Construct a new Mogwai object that can run as a thread.
     * The constructor simply initializes all of the instance's fields.
     *
     * Preconditions:
     *
     * destination = "Andreenos" or "Bandi"
     * crossTime >= 0
     * name != null
     * bridgeGuard != null
     *
     * @param name - the name of this Mogwai
     * @param crossTime - the number of seconds it takes the Mogwai to cross after it has climbed onto the bridge
     * @param destination - the Mogwai's destination city
     * @param bridgeGuard - the GremlinsBridge that the Mogwai is crossing
     */
    public Mogwai(String name, int crossTime, String destination, GremlinsBridge bridgeGuard){

        this.crossTime = crossTime;
        this.destination = destination;
        this.bridge = bridgeGuard;
        this.setName(name);
        this.secsOnBridge = 0;
    }

    /**
     * The run method handles a Mogwai's behavior as it crosses the bridge.
     * The well-behaved Mogwai asks the gremlin at the bridge to cross. While
     * it is crossing the bridge, it reports its progress each second as it works
     * its way across, and the mogwai lastly tells the gremlin that it has gotten
     * off the bridge.
     */
    @Override
    public void run() {

        if(this.secsOnBridge == 0){
            this.bridge.enterBridgePlease(this);
        }

        else {
            if(this.secsOnBridge == 1) {
                System.out.println(this.getName() + " is starting to cross.");
            }

            while(this.secsOnBridge < this.crossTime) {
                System.out.println("            " + this.getName() + " " + this.secsOnBridge + " seconds.");

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    System.out.println("Issue with sleep in Mogwai run()");
                }

                this.secsOnBridge++;
            }
            System.out.println(this.getName() + " leaves at " + this.destination);
            this.secsOnBridge = -1;
            this.bridge.leave();


        }
    }

    /**
     * returns the seconds on the bridge
     * @return the seconds on the bridge, Integer
     */
    public int getSecsOnBridge(){
        return this.secsOnBridge;
    }

    /**
     * Sets the seconds on the bridge to 1. Used for the "run" function.
     */
    public void setSecsToOne(){
        this.secsOnBridge = 1;
    }
}
