/*
 * RunMogwais.java
 *
 * Version:
 * $Id: RunMogwais.java,v 1.1 2012/05/03 21:56:42 vcss243 Exp $
 */

/**
 * Test the GremlinsBridge and Mogwais simulation.
 * Test by creating a bunch of Mogwais and let them cross the GremlinsBridge.
 * <p>
 * Note: java -enableassertions should cause Mogwais to validate their side.
 * </p>
 * @author     Ben Steele
 */
public class RunMogwais {

    /** SIDE_ONE is Andreenosn.  */
    public final static String SIDE_ONE = "Andreenos";

    /** SIDE_TWO is Bandi.  */
    public final static String SIDE_TWO = "Bandi";

    /** 
     * Command interface for collecting all the functions in this test suite.
     * Single method is Command.execute().
     */
    private interface Command {
        public void execute();
    }

    /** 
     * testSuite is the list of test cases.
     */
    private static Command[] testSuite = {
        new Command() { public void execute() { RunMogwais.test0(); }},
        new Command() { public void execute() { RunMogwais.test1(); }},
        new Command() { public void execute() { RunMogwais.test2(); }},
        new Command() { public void execute() { RunMogwais.test3(); }},
    };

    /** TEST_COUNT is number of test cases.  */
    public final static int TEST_COUNT = testSuite.length;

    /**
     * test0 is Test Scenario 0, an extremely simple, non-waiting test.
     * test0 provides an example template/pattern for writing a test case.
     */
    static void test0() {

        System.out.println( "Begin test0. ===============================\n" );

        Thread init = Thread.currentThread();      // init spawns the Mogwais

        // Create a GremlinsBridge of capacity 3.
        GremlinsBridge gremlinBridge = new GremlinsBridge( 3 );

        // Set an optional, test delay to stagger the start of each mogwai.
        int delay = 4000;

        // Create the Mogwais and store them in an array.
        Thread peds[] = {
            new Mogwai( "Al",    3, SIDE_ONE, gremlinBridge ),
            new Mogwai( "Bob",   4, SIDE_TWO, gremlinBridge ),
        };

        for ( int j = 0; j < peds.length; ++j ) {
            // Run them by calling their start() method.
            try {
                peds[j].start();
                init.sleep( delay );
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
                break;
            }
        }
        // Now, the test must give the mogwai time to finish their crossings.
        for ( int j = 0; j < peds.length; ++j ) {
            try {
                peds[j].join();
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
                break;
            }
        }
        System.out.println( "\n=============================== End test0." );
        return;
    }

    /**
     * test1 is Test Scenario 1, another fairly simple simulation run.
     * test1 provides another example for writing a test case.
     */
    static void test1() {

        System.out.println( "Begin test1. ===============================\n" );

        Thread init = Thread.currentThread();      // init spawns the Mogwais

        // Create a GremlinsBridge of capacity 3.
        GremlinsBridge gBridge = new GremlinsBridge( 3 );

        int delay = 1000;

        // Create the Mogwais and store them in an array.
        Thread peds[] = {
            new Mogwai( "Al",    3, SIDE_ONE, gBridge ),
            new Mogwai( "Bob",   2, SIDE_ONE, gBridge ),
            new Mogwai( "Cathy", 2, SIDE_TWO, gBridge ),
            new Mogwai( "Doris", 3, SIDE_TWO, gBridge ),
            new Mogwai( "Edith", 3, SIDE_ONE, gBridge ),
            new Mogwai( "Fred",  2, SIDE_TWO, gBridge ),
        };

        for ( int j = 0; j < peds.length; ++j ) {
            // Run them by calling their start() method.
            try {
                peds[j].start();
                init.sleep( delay );         // delay start of next mogwai
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
            }
        }
        // Now, the test must give the mogwai time to finish their crossings.
        for ( int j = 0; j < peds.length; ++j ) {
            try {
                peds[j].join();              // wait for next mogwai to finish
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
            }
        }

        System.out.println( "\n=============================== End test1." );
    }

    /**
     * First test case by me
     */
    static void test2() {

        System.out.println( "Begin test2. ===============================\n" );

        Thread init = Thread.currentThread();      // init spawns the Mogwais

        // Create a GremlinsBridge of capacity 3.
        GremlinsBridge gBridge = new GremlinsBridge( 3 );

        int delay = 1000;

        // Create the Mogwais and store them in an array.
        Thread peds[] = {
                new Mogwai( "Vader",     9, SIDE_ONE, gBridge),
                new Mogwai( "Han",     8, SIDE_TWO, gBridge),
                new Mogwai( "Luke",    7, SIDE_ONE, gBridge ),
                new Mogwai( "Leia",   6, SIDE_ONE, gBridge ),
                new Mogwai( "Chewie", 5, SIDE_TWO, gBridge ),
                new Mogwai( "R2D2", 4, SIDE_ONE, gBridge ),
                new Mogwai( "C3PO", 3, SIDE_TWO, gBridge ),
                new Mogwai( "Obi-Wan",  2, SIDE_ONE, gBridge ),
        };

        for ( int j = 0; j < peds.length; ++j ) {
            // Run them by calling their start() method.
            try {
                peds[j].start();
                init.sleep( delay );         // delay start of next mogwai
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
            }
        }
        // Now, the test must give the mogwai time to finish their crossings.
        for ( int j = 0; j < peds.length; ++j ) {
            try {
                peds[j].join();              // wait for next mogwai to finish
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
            }
        }

        System.out.println( "\n=============================== End test2." );
    }

    /**
     * Second test case by me
     */
    static void test3() {


        System.out.println( "Begin test3. ===============================\n" );

        Thread init = Thread.currentThread();      // init spawns the Mogwais

        // Create a GremlinsBridge of capacity 3.
        GremlinsBridge gBridge = new GremlinsBridge( 3 );

        int delay = 1000;

        // Create the Mogwais and store them in an array.
        Thread peds[] = {
                new Mogwai( "Vader",     12, SIDE_ONE, gBridge),
                new Mogwai( "Han",     2, SIDE_TWO, gBridge),
                new Mogwai( "Luke",    5, SIDE_ONE, gBridge ),
                new Mogwai( "Leia",   6, SIDE_ONE, gBridge ),
                new Mogwai( "Chewie", 20, SIDE_TWO, gBridge ),
                new Mogwai( "R2D2", 5, SIDE_ONE, gBridge ),
                new Mogwai( "C3PO", 2, SIDE_TWO, gBridge ),
                new Mogwai( "Obi-Wan",  6, SIDE_ONE, gBridge ),
                new Mogwai( "Yoda",  7, SIDE_ONE, gBridge ),
                new Mogwai( "Lando",  3, SIDE_ONE, gBridge ),
                new Mogwai( "Boba",  4, SIDE_TWO, gBridge ),
                new Mogwai( "Emperor",  3, SIDE_TWO, gBridge ),
                new Mogwai( "Jabba",  5, SIDE_ONE, gBridge ),
        };

        for ( int j = 0; j < peds.length; ++j ) {
            // Run them by calling their start() method.
            try {
                peds[j].start();
                init.sleep( delay );         // delay start of next mogwai
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
            }
        }
        // Now, the test must give the mogwai time to finish their crossings.
        for ( int j = 0; j < peds.length; ++j ) {
            try {
                peds[j].join();              // wait for next mogwai to finish
            }
            catch ( InterruptedException e ) {
                System.err.println( "Abort. Unexpected thread interruption." );
            }
        }

        System.out.println( "\n=============================== End test3." );
    }

    /**
     * Run all the tests in this test suite.
     *
     * @param args not used
     */
    public static void main( String args[] ) {

        for ( int j = 0; j < TEST_COUNT; ++j ) {
            testSuite[j].execute();
        }
    }

}

/* 
 * Revisions:
 * $Log: RunMogwais.java,v $
 * Revision 1.1  2012/05/03 21:56:42  vcss243
 * Initial revision
 *
 */
